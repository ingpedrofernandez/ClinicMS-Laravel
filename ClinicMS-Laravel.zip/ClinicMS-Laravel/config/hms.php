<?php 

//custom config variables for hospital setting
return 
[
	'invoice_prefix' => 'LWC-INV',
	'patient_prefix' => 'LWC-',
];


 ?>